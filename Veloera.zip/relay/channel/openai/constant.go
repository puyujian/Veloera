// Copyright (c) 2025 Tethys Plex
//
// This file is part of Veloera.
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
package openai

var ModelList = []string{
	"gpt-3.5-turbo", "gpt-3.5-turbo-0613", "gpt-3.5-turbo-1106", "gpt-3.5-turbo-0125",
	"gpt-3.5-turbo-16k", "gpt-3.5-turbo-16k-0613",
	"gpt-3.5-turbo-instruct",
	"gpt-4", "gpt-4-0613", "gpt-4-1106-preview", "gpt-4-0125-preview",
	"gpt-4-32k", "gpt-4-32k-0613",
	"gpt-4-turbo-preview", "gpt-4-turbo", "gpt-4-turbo-2024-04-09",
	"gpt-4-vision-preview",
	"chatgpt-4o-latest",
	"gpt-4o", "gpt-4o-2024-05-13", "gpt-4o-2024-08-06", "gpt-4o-2024-11-20",
	"gpt-4o-mini", "gpt-4o-mini-2024-07-18",
	"gpt-4.5-preview", "gpt-4.5-preview-2025-02-27",
	"o1-preview", "o1-preview-2024-09-12",
	"o1-mini", "o1-mini-2024-09-12",
	"o3-mini", "o3-mini-2025-01-31",
	"o3-mini-high", "o3-mini-2025-01-31-high",
	"o3-mini-low", "o3-mini-2025-01-31-low",
	"o3-mini-medium", "o3-mini-2025-01-31-medium",
	"o1", "o1-2024-12-17",
	"gpt-4o-audio-preview", "gpt-4o-audio-preview-2024-10-01",
	"gpt-4o-realtime-preview", "gpt-4o-realtime-preview-2024-10-01", "gpt-4o-realtime-preview-2024-12-17",
	"gpt-4o-mini-realtime-preview", "gpt-4o-mini-realtime-preview-2024-12-17",
	"text-embedding-ada-002", "text-embedding-3-small", "text-embedding-3-large",
	"text-curie-001", "text-babbage-001", "text-ada-001",
	"text-moderation-latest", "text-moderation-stable",
	"text-davinci-edit-001",
	"davinci-002", "babbage-002",
	"dall-e-3",
	"whisper-1",
	"tts-1", "tts-1-1106", "tts-1-hd", "tts-1-hd-1106",
}

var ChannelName = "openai"
